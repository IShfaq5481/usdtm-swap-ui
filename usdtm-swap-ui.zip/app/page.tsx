export default function Home() {
  return (
    <main>
      <h1>Welcome to USDTM Swap</h1>
    </main>
  );
}
