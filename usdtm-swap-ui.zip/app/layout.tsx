import './globals.css';
import React from 'react';

export const metadata = {
  title: 'USDTM Swap',
  description: 'Swap your USDT Mining Token',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
