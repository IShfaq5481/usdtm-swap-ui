import Component from "../token-swap"

export default function Page() {
  return <Component />
}
