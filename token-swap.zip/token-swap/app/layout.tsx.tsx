// app/layout.tsx

import './globals.css'; // ✅ Make sure this file exists inside the same `app` folder
import React from 'react';

export const metadata = {
  title: 'USDTM Swap',
  description: 'Swap your USDT Mining Token',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
